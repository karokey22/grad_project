﻿using System;
using System.Collections.Generic;

namespace BlazorApp2.Models;

public partial class Histroy
{
    public int Hisid { get; set; }

    public int? TicketId { get; set; }

    public string? Description { get; set; }

    public string? Level { get; set; }

    public int? Asdepid { get; set; }

    public int? Asempid { get; set; }

    public string? Status { get; set; }

    public string? LastActionDate { get; set; }

    public string? Feedback { get; set; }
}
