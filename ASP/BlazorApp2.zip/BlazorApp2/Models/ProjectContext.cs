﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BlazorApp2.Models;

public partial class ProjectContext : DbContext
{
    public ProjectContext()
    {
    }

    public ProjectContext(DbContextOptions<ProjectContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Histroy> Histroys { get; set; }

    public virtual DbSet<Ticket> Tickets { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=.;Initial Catalog=project;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Histroy>(entity =>
        {
            entity.HasKey(e => e.Hisid);

            entity.ToTable("histroy");

            entity.Property(e => e.Hisid)
                .ValueGeneratedNever()
                .HasColumnName("hisid");
            entity.Property(e => e.Asdepid).HasColumnName("asdepid");
            entity.Property(e => e.Asempid).HasColumnName("asempid");
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .HasColumnName("description");
            entity.Property(e => e.Feedback)
                .HasMaxLength(50)
                .HasColumnName("feedback");
            entity.Property(e => e.LastActionDate)
                .HasMaxLength(50)
                .HasColumnName("last action date");
            entity.Property(e => e.Level)
                .HasMaxLength(50)
                .HasColumnName("level");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .HasColumnName("status");
            entity.Property(e => e.TicketId).HasColumnName("ticket id");
        });

        modelBuilder.Entity<Ticket>(entity =>
        {
            entity.ToTable("ticket");

            entity.Property(e => e.TicketId).HasColumnName("ticket Id");
            entity.Property(e => e.Asdepid).HasColumnName("asdepid");
            entity.Property(e => e.Asempid).HasColumnName("asempid");
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .HasColumnName("description");
            entity.Property(e => e.Feedback)
                .HasMaxLength(50)
                .HasColumnName("feedback");
            entity.Property(e => e.LastActionDate)
                .HasMaxLength(50)
                .HasColumnName("last action date");
            entity.Property(e => e.PredDep)
                .HasMaxLength(50)
                .HasColumnName("predDep");
            entity.Property(e => e.Priority)
                .HasMaxLength(50)
                .HasColumnName("priority");
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("status");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("user");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.DepId).HasColumnName("DepID");
            entity.Property(e => e.Finshedtaskes).HasColumnName("finshedtaskes");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("password");
            entity.Property(e => e.Totaltasks).HasColumnName("totaltasks");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
